<!DOCTYPE html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Trip ended</title>
<style>body{font-family:system-ui,"Nirmala UI",sans-serif;background:#0f172a;color:#fff;text-align:center;padding:60px 20px}</style></head>
<body><h1>🌙 410</h1><p>This live trip link has ended or expired.<br>এই লাইভ ট্রিপ লিংকটির মেয়াদ শেষ।</p></body></html>
