<?php

namespace App\Http\Controllers;

use App\Models\ReportPhoto;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Symfony\Component\HttpFoundation\StreamedResponse;

/**
 * Serves report evidence from the private disk.
 *
 * Verified report photos are part of a venue's public record. Photos on
 * pending or rejected reports are visible only to their reporter and staff.
 */
class ReportPhotoController extends Controller
{
    public function show(Request $request, ReportPhoto $photo): StreamedResponse
    {
        $report = $photo->report;
        abort_if($report === null, 404);

        $user = $request->user();
        $isReporterOrStaff = $user !== null
            && ($user->id === $report->user_id || $user->isStaff());
        $canView = $report->status === 'verified' || $isReporterOrStaff;

        abort_unless($canView, 403);

        // Verified evidence appears on public venue pages. Restricted venues
        // are age-gated, so their photos must not bypass that gate via a URL.
        if (! $isReporterOrStaff
            && $report->venue?->is_restricted
            && ! $user?->is_adult_confirmed) {
            abort(403, 'You must confirm you are 18 or older to view this category.');
        }

        $path = (string) ($request->query('variant') === 'thumb'
            ? ($photo->thumbnail ?: $photo->path)
            : $photo->path);

        abort_unless($this->isManagedPath($path), 404);

        $disk = Storage::disk('local');
        abort_unless($disk->exists($path), 404);

        return $disk->response($path, basename($path), [
            'Content-Type' => $disk->mimeType($path) ?: 'application/octet-stream',
            'X-Content-Type-Options' => 'nosniff',
            'Cache-Control' => $report->status === 'verified'
                ? 'private, max-age=600'
                : 'private, no-store',
        ]);
    }

    private function isManagedPath(string $path): bool
    {
        return str_starts_with($path, 'reports/')
            && ! str_contains($path, '..')
            && ! str_contains($path, "\0");
    }
}
