<?php

namespace Tests\Feature;

use App\Models\Report;
use App\Models\ReportPhoto;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Storage;
use Tests\TestCase;

class ReportPhotoTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();

        Storage::fake('local');
        Storage::fake('public');
    }

    public function test_uploaded_photo_is_sanitized_stored_privately_and_linked_to_the_report(): void
    {
        $user = $this->userWithRole('user');

        $this->submitReport($user, [$this->fixture('evidence-gps.jpg')])
            ->assertRedirect('/my-reports')
            ->assertSessionHasNoErrors();

        $report = Report::firstOrFail();
        $photo = ReportPhoto::firstOrFail();

        $this->assertSame($report->id, $photo->report_id);
        $this->assertStringStartsWith('reports/'.$report->id.'/', $photo->path);
        Storage::disk('local')->assertExists($photo->path);

        if (extension_loaded('gd') && function_exists('imagejpeg')) {
            $this->assertNotSame($photo->path, $photo->thumbnail);
            Storage::disk('local')->assertExists($photo->thumbnail);
            $this->assertCount(2, Storage::disk('local')->allFiles('reports/'.$report->id));

            $thumbInfo = getimagesize(Storage::disk('local')->path($photo->thumbnail));
            $this->assertNotFalse($thumbInfo);
            $this->assertLessThanOrEqual(400, max($thumbInfo[0], $thumbInfo[1]));
        } else {
            $this->assertSame($photo->path, $photo->thumbnail, 'Without GD no duplicate full-size thumbnail should be created.');
            $this->assertCount(1, Storage::disk('local')->allFiles('reports/'.$report->id));
        }

        $this->assertSame([], Storage::disk('public')->allFiles('reports'));

        $stored = Storage::disk('local')->get($photo->path);
        $this->assertStringNotContainsString("Exif\x00\x00", $stored);
        $this->assertNotFalse(getimagesize(Storage::disk('local')->path($photo->path)));
        $this->assertFalse($this->jpegHasGps(Storage::disk('local')->path($photo->path)));

        $this->assertSame(route('reports.photos.show', $photo), $photo->url());
        $this->assertStringContainsString('variant=thumb', $photo->thumbUrl());
    }

    public function test_png_text_metadata_is_removed_before_storage(): void
    {
        $user = $this->userWithRole('user');

        $this->submitReport($user, [$this->fixture('evidence-text.png')])->assertSessionHasNoErrors();

        $photo = ReportPhoto::firstOrFail();
        $bytes = Storage::disk('local')->get($photo->path);
        $types = $this->pngChunkTypes($bytes);

        $this->assertContains('IHDR', $types);
        $this->assertContains('IEND', $types);
        $this->assertNotContains('tEXt', $types);
        $this->assertNotContains('iTXt', $types);
        $this->assertStringNotContainsString('GPS: 23.8103', $bytes);
    }

    public function test_webp_exif_chunk_is_removed_before_storage(): void
    {
        $user = $this->userWithRole('user');

        $this->submitReport($user, [$this->fixture('evidence-gps.webp')])->assertSessionHasNoErrors();

        $photo = ReportPhoto::firstOrFail();
        $bytes = Storage::disk('local')->get($photo->path);
        $types = $this->webpChunkTypes($bytes);

        $this->assertNotContains('EXIF', $types);
        $this->assertNotContains('XMP ', $types);
        $this->assertNotFalse(getimagesize(Storage::disk('local')->path($photo->path)));
    }

    public function test_pending_photo_is_hidden_from_guests_and_other_users(): void
    {
        $owner = $this->userWithRole('user');
        $other = $this->userWithRole('user');
        [$report, $photo] = $this->reportWithPhoto($owner, 'pending');

        $url = route('reports.photos.show', $photo);

        $this->get($url)->assertForbidden();
        $this->actingAs($other)->get($url)->assertForbidden();
    }

    public function test_owner_can_view_their_own_pending_photo(): void
    {
        $owner = $this->userWithRole('user');
        [, $photo] = $this->reportWithPhoto($owner, 'pending');

        $response = $this->actingAs($owner)->get(route('reports.photos.show', $photo));

        $response->assertOk()
            ->assertHeader('Content-Type', 'image/jpeg')
            ->assertHeader('X-Content-Type-Options', 'nosniff');

        $cache = (string) $response->headers->get('Cache-Control');
        $this->assertStringContainsString('private', $cache);
        $this->assertStringContainsString('no-store', $cache);
    }

    public function test_staff_can_view_pending_evidence(): void
    {
        $owner = $this->userWithRole('user');
        $staff = $this->userWithRole('safety_admin');
        [, $photo] = $this->reportWithPhoto($owner, 'pending');

        $this->actingAs($staff)
            ->get(route('reports.photos.show', $photo))
            ->assertOk();
    }

    public function test_verified_photo_is_public_but_rejected_photo_is_not(): void
    {
        $owner = $this->userWithRole('user');
        [$report, $photo] = $this->reportWithPhoto($owner, 'verified');
        $url = route('reports.photos.show', $photo);

        $response = $this->get($url);
        $response->assertOk();

        $cache = (string) $response->headers->get('Cache-Control');
        $this->assertStringContainsString('private', $cache);
        $this->assertStringContainsString('max-age=600', $cache);

        $report->update(['status' => 'rejected']);

        $this->get($url)->assertForbidden();
    }

    public function test_verified_photo_from_restricted_venue_requires_age_confirmation(): void
    {
        $owner = $this->userWithRole('user');
        $adult = $this->userWithRole('user', ['is_adult_confirmed' => true]);
        $venue = $this->makeVenue(['is_restricted' => true]);
        [, $photo] = $this->reportWithPhoto($owner, 'verified', ['venue_id' => $venue->id]);

        $url = route('reports.photos.show', $photo);

        $this->get($url)->assertForbidden();
        $this->actingAs($this->userWithRole('user'))->get($url)->assertForbidden();
        $this->actingAs($adult)->get($url)->assertOk();
    }

    public function test_reporter_and_staff_keep_access_to_restricted_venue_evidence(): void
    {
        $owner = $this->userWithRole('user');
        $staff = $this->userWithRole('safety_admin');
        $venue = $this->makeVenue(['is_restricted' => true]);
        [, $photo] = $this->reportWithPhoto($owner, 'pending', ['venue_id' => $venue->id]);

        $url = route('reports.photos.show', $photo);

        $this->actingAs($owner)->get($url)->assertOk();
        $this->actingAs($staff)->get($url)->assertOk();
    }

    public function test_thumbnail_variant_is_served(): void
    {
        $owner = $this->userWithRole('user');
        [, $photo] = $this->reportWithPhoto($owner, 'pending');

        $this->actingAs($owner)
            ->get(route('reports.photos.show', ['photo' => $photo, 'variant' => 'thumb']))
            ->assertOk()
            ->assertHeader('Content-Type', 'image/jpeg');
    }

    public function test_photo_that_cannot_be_verified_is_rejected_and_nothing_is_stored(): void
    {
        $user = $this->userWithRole('user');
        $png = file_get_contents(base_path('tests/Fixtures/evidence-text.png'));

        $file = UploadedFile::fake()->createWithContent('trailing.png', $png.'unexpected-trailing-data');

        $this->submitReport($user, [$file])->assertSessionHasErrors('photos.0');

        $this->assertSame(0, Report::count());
        $this->assertSame(0, ReportPhoto::count());
        $this->assertSame([], Storage::disk('local')->allFiles('reports'));
    }

    public function test_rejects_non_image_files(): void
    {
        $user = $this->userWithRole('user');

        $this->submitReport($user, [UploadedFile::fake()->createWithContent('notes.jpg', 'not an image')])
            ->assertSessionHasErrors('photos.0');
    }

    public function test_rejects_unsupported_image_formats(): void
    {
        $user = $this->userWithRole('user');

        $this->submitReport($user, [$this->fixture('evidence.gif')])
            ->assertSessionHasErrors('photos.0');
    }

    public function test_rejects_photos_over_five_megabytes(): void
    {
        $user = $this->userWithRole('user');
        $content = file_get_contents(base_path('tests/Fixtures/evidence-clean.jpg')).str_repeat('A', 6 * 1024 * 1024);
        $file = UploadedFile::fake()->createWithContent('large.jpg', $content);

        $this->submitReport($user, [$file])->assertSessionHasErrors('photos.0');
    }

    public function test_rejects_photos_over_the_dimension_limit(): void
    {
        $user = $this->userWithRole('user');

        $this->submitReport($user, [$this->fixture('evidence-wide.jpg')])
            ->assertSessionHasErrors('photos.0');
    }

    public function test_rejects_more_than_three_photos(): void
    {
        $user = $this->userWithRole('user');
        $photos = array_fill(0, 4, $this->fixture('evidence-clean.jpg'));

        $this->submitReport($user, $photos)->assertSessionHasErrors('photos');
    }

    public function test_deleting_a_photo_removes_files_only_after_the_last_reference(): void
    {
        $user = $this->userWithRole('user');
        $report = $this->makeReport($user);
        $path = 'reports/'.$report->id.'/shared.jpg';
        Storage::disk('local')->put($path, file_get_contents(base_path('tests/Fixtures/evidence-clean.jpg')));

        $first = ReportPhoto::create([
            'report_id' => $report->id,
            'path' => $path,
            'thumbnail' => $path,
            'size_bytes' => Storage::disk('local')->size($path),
            'created_at' => now(),
        ]);
        $second = ReportPhoto::create([
            'report_id' => $report->id,
            'path' => $path,
            'thumbnail' => $path,
            'size_bytes' => Storage::disk('local')->size($path),
            'created_at' => now(),
        ]);

        $first->delete();
        Storage::disk('local')->assertExists($path);

        $second->delete();
        Storage::disk('local')->assertMissing($path);
    }

    public function test_deleting_a_report_removes_its_photo_files(): void
    {
        $user = $this->userWithRole('user');
        $report = $this->makeReport($user);
        $full = 'reports/'.$report->id.'/full.jpg';
        $thumb = 'reports/'.$report->id.'/thumb_full.jpg';
        Storage::disk('local')->put($full, file_get_contents(base_path('tests/Fixtures/evidence-clean.jpg')));
        Storage::disk('local')->put($thumb, 'thumbnail bytes');

        $photo = ReportPhoto::create([
            'report_id' => $report->id,
            'path' => $full,
            'thumbnail' => $thumb,
            'size_bytes' => Storage::disk('local')->size($full),
            'created_at' => now(),
        ]);

        $report->delete();

        Storage::disk('local')->assertMissing($full);
        Storage::disk('local')->assertMissing($thumb);
        $this->assertDatabaseMissing('report_photos', ['id' => $photo->id]);
    }

    public function test_deleting_a_user_account_removes_report_photo_files(): void
    {
        $user = $this->userWithRole('user');
        $report = $this->makeReport($user);
        $path = 'reports/'.$report->id.'/evidence.jpg';
        Storage::disk('local')->put($path, file_get_contents(base_path('tests/Fixtures/evidence-clean.jpg')));

        $photo = ReportPhoto::create([
            'report_id' => $report->id,
            'path' => $path,
            'thumbnail' => $path,
            'size_bytes' => Storage::disk('local')->size($path),
            'created_at' => now(),
        ]);

        $this->actingAs($user)
            ->delete('/profile', ['password' => 'password'])
            ->assertRedirect('/');

        Storage::disk('local')->assertMissing($path);
        $this->assertDatabaseMissing('reports', ['id' => $report->id]);
        $this->assertDatabaseMissing('report_photos', ['id' => $photo->id]);
        $this->assertNull($user->fresh());
    }

    public function test_venue_page_uses_authorized_photo_url_for_verified_evidence(): void
    {
        $owner = $this->userWithRole('user');
        [$report, $photo] = $this->reportWithPhoto($owner, 'verified');

        $this->get(route('venues.show', $report->venue_id))
            ->assertOk()
            ->assertSee(route('reports.photos.show', $photo), false)
            ->assertSee('variant=thumb', false);
    }

    public function test_my_reports_page_uses_authorized_photo_url_for_owner(): void
    {
        $user = $this->userWithRole('user');
        $this->submitReport($user, [$this->fixture('evidence-clean.jpg')])->assertSessionHasNoErrors();
        $photo = ReportPhoto::firstOrFail();

        $this->actingAs($user)
            ->get('/my-reports')
            ->assertOk()
            ->assertSee(route('reports.photos.show', $photo), false)
            ->assertSee('variant=thumb', false);
    }

    public function test_admin_moderation_page_uses_authorized_photo_url(): void
    {
        $owner = $this->userWithRole('user');
        $staff = $this->userWithRole('safety_admin');
        [, $photo] = $this->reportWithPhoto($owner, 'pending');

        $this->actingAs($staff)
            ->get('/admin/reports')
            ->assertOk()
            ->assertSee(route('reports.photos.show', $photo), false)
            ->assertSee('variant=thumb', false);
    }

    private function submitReport(User $user, array $photos = [], array $overrides = [])
    {
        $venue = $overrides['venue'] ?? $this->makeVenue();
        unset($overrides['venue']);

        $payload = array_merge([
            'kind' => 'incident',
            'body' => 'Someone snatched my phone near the entrance at night',
            'venue_id' => $venue->id,
            'photos' => $photos,
        ], $overrides);

        return $this->actingAs($user)->post('/reports', $payload);
    }

    private function makeReport(User $user, array $overrides = []): Report
    {
        return Report::create($overrides + [
            'user_id' => $user->id,
            'venue_id' => $this->makeVenue()->id,
            'kind' => 'incident',
            'body' => 'Test report body used only for photo cleanup checks',
            'incident_time' => now()->subHour(),
            'status' => 'pending',
        ]);
    }

    /** @return array{0:Report,1:ReportPhoto} */
    private function reportWithPhoto(User $owner, string $status, array $overrides = []): array
    {
        $report = $this->makeReport($owner, $overrides + ['status' => $status]);
        $path = 'reports/'.$report->id.'/'.uniqid('photo_', true).'.jpg';
        Storage::disk('local')->put($path, file_get_contents(base_path('tests/Fixtures/evidence-clean.jpg')));

        $photo = ReportPhoto::create([
            'report_id' => $report->id,
            'path' => $path,
            'thumbnail' => $path,
            'size_bytes' => Storage::disk('local')->size($path),
            'created_at' => now(),
        ]);

        return [$report, $photo];
    }

    private function fixture(string $name): UploadedFile
    {
        $path = base_path('tests/Fixtures/'.$name);
        $this->assertFileExists($path);

        return new UploadedFile($path, $name, mime_content_type($path) ?: null, null, true);
    }

    private function jpegHasGps(string $path): bool
    {
        $exif = @exif_read_data($path);

        return is_array($exif) && (isset($exif['GPSLatitude']) || isset($exif['GPS_IFD_Pointer']));
    }

    /** @return list<string> */
    private function pngChunkTypes(string $bytes): array
    {
        $types = [];
        $pos = 8;
        $length = strlen($bytes);

        while ($pos + 12 <= $length) {
            $chunkLength = unpack('N', substr($bytes, $pos, 4))[1];
            $type = substr($bytes, $pos + 4, 4);
            $types[] = $type;
            $pos += 12 + $chunkLength;

            if ($type === 'IEND') {
                break;
            }
        }

        return $types;
    }

    /** @return list<string> */
    private function webpChunkTypes(string $bytes): array
    {
        $types = [];
        $pos = 12;
        $length = strlen($bytes);

        while ($pos + 8 <= $length) {
            $chunkLength = unpack('V', substr($bytes, $pos + 4, 4))[1];
            $types[] = substr($bytes, $pos, 4);
            $pos += 8 + $chunkLength + ($chunkLength % 2);
        }

        return $types;
    }
}
