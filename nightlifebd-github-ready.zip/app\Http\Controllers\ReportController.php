<?php

namespace App\Http\Controllers;

use App\Jobs\AnalyzeReportJob;
use App\Models\AuditLog;
use App\Models\Report;
use App\Models\ReportPhoto;
use App\Models\Venue;
use App\Services\ReportImageProcessor;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use Illuminate\Validation\Rule;
use Illuminate\Validation\ValidationException;
use Throwable;

class ReportController extends Controller
{
    public function create(Request $request)
    {
        return view('reports.create', [
            'venues' => Venue::approved()->orderBy('name')->get(['id', 'name', 'area', 'lat', 'lng']),
            'selected' => $request->integer('venue') ?: null,
        ]);
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'kind' => ['required', Rule::in(['incident', 'review'])],
            'body' => ['required', 'string', 'min:10', 'max:500'],
            'venue_id' => ['nullable', Rule::exists('venues', 'id')->where('status', 'approved')],
            'lat' => ['nullable', 'numeric', 'between:20,27'],
            'lng' => ['nullable', 'numeric', 'between:88,93'],
            'incident_time' => ['nullable', 'date', 'before_or_equal:now'],
            'is_anonymous' => ['nullable', 'boolean'],
            'rating' => ['nullable', 'integer', 'between:1,5'],
            'photos' => ['nullable', 'array', 'max:3'],
            'photos.*' => [
                'image',
                'mimes:jpg,jpeg,png,webp',
                'mimetypes:image/jpeg,image/png,image/webp',
                'max:5120', // 5 MB each
                'dimensions:max_width=8000,max_height=8000',
            ],
        ], [
            'body.max' => 'Reports are limited to 500 characters.',
            'body.min' => 'Please describe what happened in at least 10 characters.',
            'photos.max' => 'You may upload up to 3 photos.',
            'photos.*.max' => 'Each photo must be under 5 MB.',
            'photos.*.mimetypes' => 'Photos must be JPEG, PNG or WebP images.',
            'photos.*.dimensions' => 'Each photo must be no larger than 8000 × 8000 pixels.',
        ]);

        if (empty($data['venue_id']) && (empty($data['lat']) || empty($data['lng']))) {
            return back()->withInput()->withErrors(['venue_id' => 'Choose a venue or click the map to mark the place.']);
        }

        // Rating is only allowed for reviews
        $rating = ($data['kind'] === 'review' && ! empty($data['rating'])) ? $data['rating'] : null;

        $photos = $request->file('photos', []);
        if (! is_array($photos)) {
            $photos = [$photos];
        }

        // Strip metadata before the report exists, so an unsafe upload
        // never leaves a report (or any file) behind.
        $processor = app(ReportImageProcessor::class);
        foreach ($photos as $index => $file) {
            $source = $file->getRealPath();
            $mime = $processor->normalizeMimeType($file->getMimeType());

            if (! is_string($source) || ! $processor->stripMetadata($source, $mime)) {
                throw ValidationException::withMessages([
                    "photos.{$index}" => __('This photo could not be processed securely. Please upload a different JPEG, PNG or WebP image.'),
                ]);
            }
        }

        $storedPaths = [];

        try {
            $report = DB::transaction(function () use ($data, $rating, $request, $photos, $processor, &$storedPaths) {
                $report = Report::create([
                    'user_id' => $request->user()->id,
                    'venue_id' => $data['venue_id'] ?? null,
                    'kind' => $data['kind'],
                    'body' => strip_tags($data['body']),
                    'lat' => $data['lat'] ?? null,
                    'lng' => $data['lng'] ?? null,
                    'incident_time' => ! empty($data['incident_time']) ? \Carbon\Carbon::parse($data['incident_time']) : now(),
                    'is_anonymous' => $request->boolean('is_anonymous'),
                    'rating' => $rating,
                    'status' => 'pending',
                ]);
                AuditLog::record($request->user()->id, 'report.submitted', ['report_id' => $report->id]);

                $directory = 'reports/'.$report->id;

                foreach ($photos as $file) {
                    $mime = $processor->normalizeMimeType($file->getMimeType());
                    $extension = match ($mime) {
                        'image/jpeg' => 'jpg',
                        'image/png' => 'png',
                        'image/webp' => 'webp',
                        default => throw new \RuntimeException('Unsupported report photo type.'),
                    };

                    $name = Str::random(40).'.'.$extension;
                    $path = $directory.'/'.$name;

                    // Track the path before writing so a partial file is also
                    // removed if the write fails or the transaction rolls back.
                    $storedPaths[] = $path;
                    if (! Storage::disk('local')->putFileAs($directory, $file, $name)) {
                        throw new \RuntimeException('Unable to store the uploaded report photo.');
                    }

                    // Store a genuine resized thumbnail when GD is available.
                    // Otherwise reuse the sanitized original instead of copying it.
                    $thumbPath = $path;
                    $thumbBytes = $processor->thumbnail((string) $file->getRealPath(), $mime);
                    if ($thumbBytes !== null) {
                        $thumbPath = $directory.'/thumb_'.$name;
                        $storedPaths[] = $thumbPath;
                        if (! Storage::disk('local')->put($thumbPath, $thumbBytes)) {
                            throw new \RuntimeException('Unable to store the report photo thumbnail.');
                        }
                    }

                    ReportPhoto::create([
                        'report_id' => $report->id,
                        'path' => $path,
                        'thumbnail' => $thumbPath,
                        'size_bytes' => Storage::disk('local')->size($path),
                        'created_at' => now(),
                    ]);
                }

                return $report;
            });
        } catch (Throwable $e) {
            if ($storedPaths !== []) {
                Storage::disk('local')->delete($storedPaths);
            }

            throw $e;
        }

        AnalyzeReportJob::send($report->id);

        return redirect()->route('reports.mine')->with('status', __('Thank you. Your report was submitted and is being analysed by AI before moderator review.'));
    }

    public function mine(Request $request)
    {
        return view('reports.mine', [
            'reports' => $request->user()->reports()->with(['venue:id,name', 'photos'])->latest()->paginate(15),
        ]);
    }
}

