<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Support\Facades\Storage;

class ReportPhoto extends Model
{
    public $timestamps = false;

    protected $guarded = [];

    protected function casts(): array
    {
        return ['created_at' => 'datetime'];
    }

    public function report(): BelongsTo
    {
        return $this->belongsTo(Report::class);
    }

    protected static function booted(): void
    {
        static::deleting(function (ReportPhoto $photo) {
            $photo->deleteStoredFile($photo->path);

            if ($photo->thumbnail && $photo->thumbnail !== $photo->path) {
                $photo->deleteStoredFile($photo->thumbnail);
            }
        });
    }

    /** Public URL for the full image (authorization is enforced by the route). */
    public function url(): string
    {
        return route('reports.photos.show', $this);
    }

    /** URL for the thumbnail, falling back to the sanitized original. */
    public function thumbUrl(): string
    {
        return route('reports.photos.show', ['photo' => $this, 'variant' => 'thumb']);
    }

    private function deleteStoredFile(?string $path): void
    {
        $path = (string) $path;

        if ($path === '') {
            return;
        }

        $stillReferenced = static::query()
            ->whereKeyNot($this->getKey())
            ->where(fn ($query) => $query->where('path', $path)->orWhere('thumbnail', $path))
            ->exists();

        if (! $stillReferenced) {
            Storage::disk('local')->delete($path);
        }
    }
}
