<svg viewBox="0 0 32 32" xmlns="http://www.w3.org/2000/svg" {{ $attributes }}>
    <rect width="32" height="32" rx="8" fill="#0f172a"/>
    <path d="M20.5 6.5a9.5 9.5 0 1 0 5 16.9A10.5 10.5 0 0 1 20.5 6.5z" fill="#facc15"/>
    <circle cx="23" cy="9" r="1.2" fill="#fff"/><circle cx="26" cy="13" r=".8" fill="#fff"/>
</svg>
