<?php

namespace Tests\Unit;

use App\Services\ReportImageProcessor;
use Tests\TestCase;

class ReportImageProcessorTest extends TestCase
{
    /** @var list<string> */
    private array $temps = [];

    protected function tearDown(): void
    {
        foreach ($this->temps as $path) {
            @unlink($path);
        }

        parent::tearDown();
    }

    public function test_strips_gps_exif_from_jpeg(): void
    {
        $path = $this->copyFixture('evidence-gps.jpg');
        $processor = new ReportImageProcessor();

        $this->assertTrue($processor->stripMetadata($path, 'image/jpeg'));
        $this->assertFalse($this->jpegHasGps($path));
        $this->assertStringNotContainsString("Exif\x00\x00", file_get_contents($path));
        $this->assertNotFalse(getimagesize($path));
    }

    public function test_removes_png_text_chunks(): void
    {
        $path = $this->copyFixture('evidence-text.png');
        $processor = new ReportImageProcessor();

        $this->assertTrue($processor->stripMetadata($path, 'image/png'));

        $types = $this->pngChunkTypes(file_get_contents($path));
        $this->assertContains('IHDR', $types);
        $this->assertContains('IEND', $types);
        $this->assertNotContains('tEXt', $types);
        $this->assertNotContains('iTXt', $types);
        $this->assertNotContains('zTXt', $types);
    }

    public function test_removes_webp_exif_and_xmp_chunks_and_clears_flags(): void
    {
        $path = $this->copyFixture('evidence-gps.webp');
        $processor = new ReportImageProcessor();

        $this->assertTrue($processor->stripMetadata($path, 'image/webp'));

        $bytes = file_get_contents($path);
        $types = $this->webpChunkTypes($bytes);
        $this->assertNotContains('EXIF', $types);
        $this->assertNotContains('XMP ', $types);
        $this->assertSame(0, $this->webpVp8xFlags($bytes) & 0x0C);
        $this->assertNotFalse(getimagesize($path));
    }

    public function test_keeps_a_clean_jpeg_unchanged_and_valid(): void
    {
        $path = $this->copyFixture('evidence-clean.jpg');
        $before = file_get_contents($path);
        $processor = new ReportImageProcessor();

        $this->assertTrue($processor->stripMetadata($path, 'image/jpeg'));
        $this->assertSame($before, file_get_contents($path));
        $this->assertNotFalse(getimagesize($path));
    }

    public function test_rejects_corrupt_and_truncated_images(): void
    {
        $processor = new ReportImageProcessor();

        $jpeg = $this->tempFile("\xFF\xD8not-a-real-jpeg");
        $this->assertFalse($processor->stripMetadata($jpeg, 'image/jpeg'));

        $png = $this->tempFile(substr(file_get_contents(base_path('tests/Fixtures/evidence-text.png')), 0, 40));
        $this->assertFalse($processor->stripMetadata($png, 'image/png'));

        $webp = $this->tempFile('RIFF'."\x00\x00\x00\x00".'WEBPbroken');
        $this->assertFalse($processor->stripMetadata($webp, 'image/webp'));
    }

    public function test_rejects_unsupported_mime_types(): void
    {
        $path = $this->copyFixture('evidence.gif');
        $processor = new ReportImageProcessor();

        $this->assertFalse($processor->supports('image/gif'));
        $this->assertFalse($processor->stripMetadata($path, 'image/gif'));
        $this->assertFalse($processor->stripMetadata($path, 'text/plain'));
    }

    public function test_normalizes_jpeg_mime_aliases(): void
    {
        $processor = new ReportImageProcessor();

        $this->assertSame('image/jpeg', $processor->normalizeMimeType('image/jpg'));
        $this->assertSame('image/jpeg', $processor->normalizeMimeType('image/pjpeg'));
        $this->assertSame('image/webp', $processor->normalizeMimeType('IMAGE/WEBP'));
    }

    public function test_does_not_claim_a_thumbnail_when_gd_is_unavailable(): void
    {
        $path = $this->copyFixture('evidence-clean.jpg');
        $processor = new ReportImageProcessor();

        $thumbnail = $processor->thumbnail($path, 'image/jpeg');

        if (extension_loaded('gd') && function_exists('imagejpeg')) {
            $this->assertIsString($thumbnail);
            $this->assertNotFalse(getimagesizefromstring($thumbnail));
        } else {
            $this->assertNull($thumbnail, 'Without GD the processor must not pretend it resized the image.');
        }
    }

    private function copyFixture(string $name): string
    {
        $tmp = tempnam(sys_get_temp_dir(), 'nlbd_processor_');
        copy(base_path('tests/Fixtures/'.$name), $tmp);
        $this->temps[] = $tmp;

        return $tmp;
    }

    private function tempFile(string $bytes): string
    {
        $tmp = tempnam(sys_get_temp_dir(), 'nlbd_processor_');
        file_put_contents($tmp, $bytes);
        $this->temps[] = $tmp;

        return $tmp;
    }

    private function jpegHasGps(string $path): bool
    {
        $exif = @exif_read_data($path);

        return is_array($exif) && (isset($exif['GPSLatitude']) || isset($exif['GPS_IFD_Pointer']));
    }

    /** @return list<string> */
    private function pngChunkTypes(string $bytes): array
    {
        $types = [];
        $pos = 8;
        $length = strlen($bytes);

        while ($pos + 12 <= $length) {
            $chunkLength = unpack('N', substr($bytes, $pos, 4))[1];
            $type = substr($bytes, $pos + 4, 4);
            $types[] = $type;
            $pos += 12 + $chunkLength;

            if ($type === 'IEND') {
                break;
            }
        }

        return $types;
    }

    /** @return list<string> */
    private function webpChunkTypes(string $bytes): array
    {
        $types = [];
        $pos = 12;
        $length = strlen($bytes);

        while ($pos + 8 <= $length) {
            $chunkLength = unpack('V', substr($bytes, $pos + 4, 4))[1];
            $types[] = substr($bytes, $pos, 4);
            $pos += 8 + $chunkLength + ($chunkLength % 2);
        }

        return $types;
    }

    private function webpVp8xFlags(string $bytes): int
    {
        $pos = 12;
        $length = strlen($bytes);

        while ($pos + 8 <= $length) {
            $chunkLength = unpack('V', substr($bytes, $pos + 4, 4))[1];
            if (substr($bytes, $pos, 4) === 'VP8X') {
                return ord($bytes[$pos + 8]);
            }
            $pos += 8 + $chunkLength + ($chunkLength % 2);
        }

        return 0;
    }
}
