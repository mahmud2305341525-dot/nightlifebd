<?php

namespace App\Services;

/**
 * Prepares uploaded report photos before they are stored.
 *
 * Report evidence often carries EXIF GPS coordinates, XMP, IPTC or PNG/WebP
 * text metadata. This processor removes those containers with pure PHP (so it
 * works even when the GD/Imagick extensions are not installed), then verifies
 * the result before the caller is allowed to store the file.
 *
 * Thumbnails are generated only when GD can actually resize the image. When it
 * cannot, the caller stores the sanitized original as the thumbnail path
 * instead of creating a second full-size copy.
 */
class ReportImageProcessor
{
    public const THUMBNAIL_MAX = 400;

    /** Refuse to decode more than this many pixels into GD memory. */
    private const MAX_THUMBNAIL_PIXELS = 16_000_000;

    /** @var list<string> */
    private const SUPPORTED_MIMES = ['image/jpeg', 'image/png', 'image/webp'];

    public function normalizeMimeType(?string $mime): string
    {
        $mime = strtolower(trim((string) $mime));

        return match ($mime) {
            'image/jpg', 'image/pjpeg' => 'image/jpeg',
            default => $mime,
        };
    }

    public function supports(string $mime): bool
    {
        return in_array($this->normalizeMimeType($mime), self::SUPPORTED_MIMES, true);
    }

    /**
     * Remove metadata from the file in place.
     *
     * Returns false for unsupported, corrupt or unverifiable images. Callers
     * must treat false as a validation failure and must not store the file.
     */
    public function stripMetadata(string $path, string $mime): bool
    {
        $mime = $this->normalizeMimeType($mime);
        if (! $this->supports($mime)) {
            return false;
        }

        $original = @file_get_contents($path);
        if ($original === false) {
            return false;
        }

        $clean = match ($mime) {
            'image/jpeg' => $this->cleanJpeg($original),
            'image/png' => $this->cleanPng($original),
            'image/webp' => $this->cleanWebp($original),
            default => null,
        };

        if ($clean === null) {
            return false;
        }

        // Verify a temporary copy first so a failed check never modifies the upload.
        $tmp = tempnam(sys_get_temp_dir(), 'nlbd_photo_');
        if ($tmp === false) {
            return false;
        }

        try {
            if (@file_put_contents($tmp, $clean) !== strlen($clean)) {
                return false;
            }

            if (! $this->metadataRemoved($tmp, $mime)) {
                return false;
            }
        } finally {
            @unlink($tmp);
        }

        if ($clean === $original) {
            return true;
        }

        return @file_put_contents($path, $clean) === strlen($clean)
            && $this->metadataRemoved($path, $mime);
    }

    /**
     * Return resized image bytes, or null when a genuine resize is not possible.
     */
    public function thumbnail(string $path, string $mime): ?string
    {
        $mime = $this->normalizeMimeType($mime);
        if (! $this->gdCanResize($mime)) {
            return null;
        }

        $info = @getimagesize($path);
        if (! is_array($info) || ($info[0] ?? 0) < 1 || ($info[1] ?? 0) < 1) {
            return null;
        }

        [$width, $height] = $info;
        if ($width * $height > self::MAX_THUMBNAIL_PIXELS) {
            return null;
        }

        $scale = min(1, self::THUMBNAIL_MAX / max($width, $height));
        $thumbWidth = max(1, (int) round($width * $scale));
        $thumbHeight = max(1, (int) round($height * $scale));

        $source = @imagecreatefromstring((string) @file_get_contents($path));
        if (! $source) {
            return null;
        }

        $thumbnail = imagecreatetruecolor($thumbWidth, $thumbHeight);
        if (! $thumbnail) {
            imagedestroy($source);

            return null;
        }

        if (in_array($mime, ['image/png', 'image/webp'], true)) {
            imagealphablending($thumbnail, false);
            imagesavealpha($thumbnail, true);
            $transparent = imagecolorallocatealpha($thumbnail, 0, 0, 0, 127);
            imagefilledrectangle($thumbnail, 0, 0, $thumbWidth, $thumbHeight, $transparent);
        }

        imagecopyresampled($thumbnail, $source, 0, 0, 0, 0, $thumbWidth, $thumbHeight, $width, $height);

        ob_start();
        $ok = match ($mime) {
            'image/jpeg' => imagejpeg($thumbnail, null, 82),
            'image/png' => imagepng($thumbnail, null, 6),
            'image/webp' => imagewebp($thumbnail, null, 82),
            default => false,
        };
        $bytes = ob_get_clean();

        imagedestroy($source);
        imagedestroy($thumbnail);

        return $ok && is_string($bytes) && $bytes !== '' ? $bytes : null;
    }

    private function gdCanResize(string $mime): bool
    {
        if (! extension_loaded('gd') || ! function_exists('imagecreatefromstring') || ! function_exists('imagecopyresampled')) {
            return false;
        }

        return match ($mime) {
            'image/jpeg' => function_exists('imagejpeg'),
            'image/png' => function_exists('imagepng'),
            'image/webp' => function_exists('imagewebp')
                && defined('IMG_WEBP')
                && (imagetypes() & IMG_WEBP) !== 0,
            default => false,
        };
    }

    private function metadataRemoved(string $path, string $mime): bool
    {
        // Re-parsing also proves the sanitized file is still a valid image.
        $info = @getimagesize($path);
        if (! is_array($info) || ($info[0] ?? 0) < 1 || ($info[1] ?? 0) < 1) {
            return false;
        }

        $data = @file_get_contents($path);
        if ($data === false) {
            return false;
        }

        return match ($mime) {
            'image/jpeg' => $this->jpegIsClean($path, $data),
            'image/png' => $this->pngIsClean($data),
            'image/webp' => $this->webpIsClean($data),
            default => false,
        };
    }

    private function jpegIsClean(string $path, string $data): bool
    {
        // App1 (EXIF/XMP), App13 (IPTC) and COM are removed by cleanJpeg().
        if (str_contains($data, "Exif\x00\x00")) {
            return false;
        }
        if (str_contains($data, 'http://ns.adobe.com/xap/1.0/')) {
            return false;
        }
        if (str_contains($data, 'http://ns.adobe.com/xmp/extension/')) {
            return false;
        }
        if (str_contains($data, "Photoshop 3.0\x00")) {
            return false;
        }

        $exif = function_exists('exif_read_data') ? @exif_read_data($path) : false;
        if (is_array($exif)) {
            foreach (array_keys($exif) as $key) {
                if (str_starts_with($key, 'GPS')
                    || in_array($key, ['Make', 'Model', 'Artist', 'Copyright', 'ImageDescription', 'DateTimeOriginal'], true)) {
                    return false;
                }
            }
        }

        return true;
    }

    private function cleanJpeg(string $data): ?string
    {
        $length = strlen($data);
        if ($length < 4 || substr($data, 0, 2) !== "\xFF\xD8") {
            return null;
        }

        $out = "\xFF\xD8";
        $pos = 2;

        while ($pos + 1 < $length) {
            if ($data[$pos] !== "\xFF") {
                return null;
            }

            $marker = ord($data[$pos + 1]);

            // Fill bytes before a marker.
            if ($marker === 0xFF) {
                $pos++;
                continue;
            }

            if ($marker === 0xD8) {
                return null;
            }

            if ($marker === 0xD9) {
                return $out."\xFF\xD9";
            }

            // TEM and restart markers have no length field.
            if ($marker === 0x01 || ($marker >= 0xD0 && $marker <= 0xD7)) {
                $out .= "\xFF".chr($marker);
                $pos += 2;
                continue;
            }

            if ($pos + 4 > $length) {
                return null;
            }

            $segmentLength = unpack('n', substr($data, $pos + 2, 2))[1];
            if ($segmentLength < 2 || $pos + 2 + $segmentLength > $length) {
                return null;
            }

            $segment = substr($data, $pos, 2 + $segmentLength);
            $strip = in_array($marker, [0xE1, 0xED, 0xFE], true); // APP1, APP13, COM

            if (! $strip) {
                $out .= $segment;
            }

            $pos += 2 + $segmentLength;

            if ($marker === 0xDA) {
                // Entropy-coded data: copy through EOI, dropping anything appended after it.
                $rest = substr($data, $pos);
                $eoi = strpos($rest, "\xFF\xD9");
                if ($eoi === false) {
                    return null;
                }

                return $out.substr($rest, 0, $eoi + 2);
            }
        }

        return null;
    }

    private function pngIsClean(string $data): bool
    {
        $types = $this->pngChunkTypes($data);

        return $types !== null
            && array_intersect($types, ['eXIf', 'tEXt', 'iTXt', 'zTXt', 'tIME']) === [];
    }

    private function cleanPng(string $data): ?string
    {
        $length = strlen($data);
        if ($length < 8 || substr($data, 0, 8) !== "\x89PNG\r\n\x1a\n") {
            return null;
        }

        $out = substr($data, 0, 8);
        $pos = 8;
        $first = true;
        $ended = false;

        while ($pos + 12 <= $length) {
            $chunkLength = unpack('N', substr($data, $pos, 4))[1];
            if ($chunkLength > 0x7FFFFFFF || $pos + 12 + $chunkLength > $length) {
                return null;
            }

            $type = substr($data, $pos + 4, 4);
            if ($first && $type !== 'IHDR') {
                return null;
            }
            $first = false;

            $chunk = substr($data, $pos, 12 + $chunkLength);
            if (! in_array($type, ['eXIf', 'tEXt', 'iTXt', 'zTXt', 'tIME'], true)) {
                $out .= $chunk;
            }

            $pos += 12 + $chunkLength;

            if ($type === 'IEND') {
                if ($chunkLength !== 0) {
                    return null;
                }
                $ended = true;
                break;
            }
        }

        return $ended && $pos === $length ? $out : null;
    }

    /** @return list<string>|null */
    private function pngChunkTypes(string $data): ?array
    {
        $length = strlen($data);
        if ($length < 8 || substr($data, 0, 8) !== "\x89PNG\r\n\x1a\n") {
            return null;
        }

        $types = [];
        $pos = 8;
        $ended = false;

        while ($pos + 12 <= $length) {
            $chunkLength = unpack('N', substr($data, $pos, 4))[1];
            if ($chunkLength > 0x7FFFFFFF || $pos + 12 + $chunkLength > $length) {
                return null;
            }

            $type = substr($data, $pos + 4, 4);
            if ($types === [] && $type !== 'IHDR') {
                return null;
            }

            $types[] = $type;
            $pos += 12 + $chunkLength;

            if ($type === 'IEND') {
                $ended = true;
                break;
            }
        }

        return $ended && $pos === $length ? $types : null;
    }

    private function webpIsClean(string $data): bool
    {
        $chunks = $this->webpChunks($data);
        if ($chunks === null) {
            return false;
        }

        $hasImage = false;
        foreach ($chunks as $chunk) {
            if (in_array($chunk['type'], ['EXIF', 'XMP '], true)) {
                return false;
            }
            if ($chunk['type'] === 'VP8X' && $chunk['data'] !== '' && (ord($chunk['data'][0]) & 0x0C) !== 0) {
                return false;
            }
            if (in_array($chunk['type'], ['VP8 ', 'VP8L', 'ANMF'], true)) {
                $hasImage = true;
            }
        }

        return $hasImage;
    }

    private function cleanWebp(string $data): ?string
    {
        $length = strlen($data);
        if ($length < 12 || substr($data, 0, 4) !== 'RIFF' || substr($data, 8, 4) !== 'WEBP') {
            return null;
        }

        $declared = unpack('V', substr($data, 4, 4))[1];
        if ($declared + 8 !== $length) {
            return null;
        }

        $out = '';
        $pos = 12;

        while ($pos + 8 <= $length) {
            $type = substr($data, $pos, 4);
            $chunkLength = unpack('V', substr($data, $pos + 4, 4))[1];
            $total = 8 + $chunkLength + ($chunkLength % 2);

            if ($pos + $total > $length) {
                return null;
            }

            if (! in_array($type, ['EXIF', 'XMP '], true)) {
                $chunk = substr($data, $pos, $total);

                // Clear the EXIF/XMP flags in the VP8X feature chunk.
                if ($type === 'VP8X' && $chunkLength >= 1) {
                    $chunk[8] = chr(ord($chunk[8]) & ~0x0C);
                }

                $out .= $chunk;
            }

            $pos += $total;
        }

        if ($pos !== $length) {
            return null;
        }

        $payload = 'WEBP'.$out;

        return 'RIFF'.pack('V', strlen($payload)).$payload;
    }

    /** @return list<array{type:string,data:string}>|null */
    private function webpChunks(string $data): ?array
    {
        $length = strlen($data);
        if ($length < 12 || substr($data, 0, 4) !== 'RIFF' || substr($data, 8, 4) !== 'WEBP') {
            return null;
        }

        if (unpack('V', substr($data, 4, 4))[1] + 8 !== $length) {
            return null;
        }

        $chunks = [];
        $pos = 12;

        while ($pos + 8 <= $length) {
            $type = substr($data, $pos, 4);
            $chunkLength = unpack('V', substr($data, $pos + 4, 4))[1];
            $total = 8 + $chunkLength + ($chunkLength % 2);

            if ($pos + $total > $length) {
                return null;
            }

            $chunks[] = ['type' => $type, 'data' => substr($data, $pos + 8, $chunkLength)];
            $pos += $total;
        }

        return $pos === $length && $chunks !== [] ? $chunks : null;
    }
}
