<x-app-layout>
    <x-slot name="header">
        <h1 class="font-extrabold text-2xl text-red-600 flex items-center gap-2">🆘 SOS / জরুরি সাহায্য</h1>
        <p class="text-sm text-slate-500 mt-1">{{ __('Hold the red button for 3 seconds or double-tap it. Works from every page via the floating button.') }}</p>
    </x-slot>

    <div class="max-w-2xl mx-auto p-4 space-y-5">

        {{-- Big pulsing SOS button --}}
        <div class="flex justify-center py-4">
            <div class="relative">
                {{-- Pulse ring animation --}}
                <span class="absolute inset-0 rounded-full bg-red-400 opacity-50 animate-ping"></span>
                <button type="button"
                    onclick="window.NLSOS_TRIGGER && window.NLSOS_TRIGGER()"
                    class="relative w-44 h-44 rounded-full bg-red-600 hover:bg-red-500 active:scale-95 text-white text-4xl font-extrabold shadow-2xl ring-8 ring-red-200 transition-transform duration-150 select-none"
                    style="touch-action:manipulation;-webkit-user-select:none;user-select:none"
                    title="{{ __('Hold 3 seconds or double-tap') }}">
                    SOS
                </button>
            </div>
        </div>

        {{-- Direct call button --}}
        <a href="tel:999" class="flex items-center justify-center gap-2 rounded-xl bg-slate-900 text-white py-4 text-lg font-bold shadow-md hover:bg-slate-800 transition">
            📞 {{ __('Call 999 (Police / Ambulance / Fire)') }}
        </a>

        {{-- GPS status --}}
        <div class="bg-white rounded-xl shadow-sm p-4 flex items-center gap-3">
            <div id="gps-icon" class="text-2xl">⏳</div>
            <div>
                <div class="font-semibold text-sm">{{ __('Location status') }}</div>
                <div id="gps-status" class="text-sm text-slate-500">{{ __('Checking your GPS…') }}</div>
            </div>
        </div>

        {{-- Emergency contacts --}}
        <div class="bg-white rounded-xl shadow-sm p-4">
            <h2 class="font-semibold mb-2 flex items-center gap-1">👥 {{ __('Your emergency contacts') }}</h2>
            @php $contacts = auth()->user()->emergencyContacts()->get(); @endphp
            @forelse ($contacts as $c)
                <div class="flex items-center justify-between py-2 border-b last:border-0">
                    <div>
                        <div class="font-medium text-sm">{{ $c->name }} <span class="text-xs text-slate-400">· {{ $c->relation }}</span></div>
                        <div class="text-xs text-slate-500">📱 {{ $c->phone }}</div>
                    </div>
                    <a href="sms:{{ $c->phone }}" class="text-xs bg-red-100 text-red-700 px-3 py-1 rounded-full font-semibold hover:bg-red-200 transition">{{ __('SMS') }}</a>
                </div>
            @empty
                <div class="text-sm text-amber-800 bg-amber-50 border border-amber-200 rounded-lg p-3">
                    ⚠️ {{ __('No emergency contacts set.') }}
                    <a href="{{ route('contacts.index') }}" class="underline font-semibold ml-1">{{ __('Add contacts') }}</a>
                    {{ __('so SOS can alert them automatically.') }}
                </div>
            @endforelse
        </div>

        {{-- Nearest help points (loaded via JS) --}}
        <div class="bg-white rounded-xl shadow-sm p-4">
            <h2 class="font-semibold mb-2 flex items-center gap-1">🏥 {{ __('Nearest help points') }}</h2>
            <div id="havens-list" class="text-sm text-slate-500">{{ __('Enable location to see nearby police, hospitals and pharmacies.') }}</div>
        </div>

        {{-- How it works --}}
        <div class="bg-white rounded-xl shadow-sm p-4 text-sm space-y-2">
            <h2 class="font-semibold mb-1">{{ __('How SOS works') }}</h2>
            <p>✔ {{ __('Opens a pre-filled SMS with your Google Maps location for each emergency contact.') }}</p>
            <p>✔ {{ __('Emails / Telegram-messages your contacts automatically (if configured).') }}</p>
            <p>✔ {{ __('Works offline: SMS and call buttons and nearest help points are cached on this phone.') }}</p>
            <p>⏱ {{ __('A repeat press within 60 seconds asks for confirmation to prevent accidental triggers.') }}</p>
        </div>

        {{-- Quick links to other safety tools --}}
        <div class="grid grid-cols-3 gap-3 text-center text-sm">
            <a href="{{ route('trips.index') }}" class="bg-white rounded-xl shadow-sm p-3 hover:shadow-md transition">
                <div class="text-2xl mb-1">📍</div>
                <div class="font-semibold">{{ __('Live trip') }}</div>
            </a>
            <a href="{{ route('timer.index') }}" class="bg-white rounded-xl shadow-sm p-3 hover:shadow-md transition">
                <div class="text-2xl mb-1">⏱️</div>
                <div class="font-semibold">{{ __('Safety timer') }}</div>
            </a>
            <a href="{{ route('fakecall') }}" class="bg-white rounded-xl shadow-sm p-3 hover:shadow-md transition">
                <div class="text-2xl mb-1">📞</div>
                <div class="font-semibold">{{ __('Fake call') }}</div>
            </a>
        </div>
    </div>

    @push('scripts')
    <script>
        // GPS status display
        const gpsIcon   = document.getElementById('gps-icon');
        const gpsStatus = document.getElementById('gps-status');
        const havensList = document.getElementById('havens-list');

        if ('geolocation' in navigator) {
            navigator.geolocation.getCurrentPosition(
                pos => {
                    gpsIcon.textContent   = '✅';
                    gpsStatus.textContent = `{{ __('Location active') }} (${pos.coords.latitude.toFixed(4)}, ${pos.coords.longitude.toFixed(4)}) — {{ __('will be included in SOS.') }}`;
                    gpsStatus.classList.replace('text-slate-500', 'text-green-700');

                    // Load nearest help points
                    fetch(`/api/nearest?lat=${pos.coords.latitude}&lng=${pos.coords.longitude}`)
                        .then(r => r.json())
                        .then(items => {
                            if (!items.length) { havensList.textContent = '{{ __("No help points found nearby.") }}'; return; }
                            const icons = { police: '👮', hospital: '🏥', pharmacy: '💊' };
                            havensList.innerHTML = items.slice(0, 5).map(h =>
                                `<div class="flex justify-between items-center py-1.5 border-b last:border-0">
                                    <span>${icons[h.type] || '📍'} <strong>${h.name}</strong><span class="text-slate-400 text-xs ml-1">${h.type}</span></span>
                                    <span class="text-xs text-slate-500">${(h.distance_m/1000).toFixed(1)} km · ~${h.eta_min} min</span>
                                </div>`
                            ).join('');
                        })
                        .catch(() => { havensList.textContent = '{{ __("Could not load help points.") }}'; });
                },
                err => {
                    gpsIcon.textContent   = '❌';
                    gpsStatus.textContent = '{{ __("Location unavailable. SOS will still alert your contacts without a map link.") }}';
                    gpsStatus.classList.replace('text-slate-500', 'text-amber-700');
                }
            );
        } else {
            gpsIcon.textContent   = '❌';
            gpsStatus.textContent = '{{ __("Geolocation not supported on this browser.") }}';
        }
    </script>
    @endpush
</x-app-layout>
